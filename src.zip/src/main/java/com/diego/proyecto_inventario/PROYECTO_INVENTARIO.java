/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.diego.proyecto_inventario;

/**
 *
 * @author diego
 */
public class PROYECTO_INVENTARIO {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
