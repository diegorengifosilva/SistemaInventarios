package modelo;

import java.io.Serializable;

public enum TipoTransaccion implements Serializable {
    ENTRADA,
    SALIDA
}
